# Beyond.Trades — Vercel starter

A premium black-and-gold Next.js starter for a trader workspace.

## Run locally
1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open http://localhost:3000

## Deploy to Vercel
1. Create a GitHub repository and upload this project.
2. Sign in to Vercel and choose **Add New → Project**.
3. Import the GitHub repository.
4. Keep the detected Next.js settings and deploy.

## Important prototype limitations
- Trading journal entries and partner directory data are stored in browser localStorage. They are not cloud-synced, private multi-user records, or backed up.
- The position sizing output is a simplified estimate. Instrument contract sizes, pip values, account currencies, commissions and broker specifications must be incorporated before using it for live orders.
- The booking form is a front-end placeholder and does not send or store requests.
- Course cards are informational placeholders; checkout, course access, student accounts and job-board workflows need integration.
- Admin panel is not authenticated. Do not publish it as a real admin system until authentication, database permissions and secure file storage are implemented.
- Replace starter directory entries with verified partner details and clearly label affiliate relationships.
- Legal pages must be reviewed for the actual operating entity, markets, services and applicable laws.

## Recommended production stack
- Supabase Auth + Postgres for accounts, trades, journal images and partner content.
- Supabase Storage or Cloudinary for company logos and trade screenshots.
- Cal.com or Calendly for booking.
- Stripe or a suitable local payment provider for course checkout (confirm country availability).
- Protected admin routes and server-side authorization.
